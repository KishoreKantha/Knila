﻿namespace Contact_API.BO
{
    public class RequiredData
    {
        public long Id { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
