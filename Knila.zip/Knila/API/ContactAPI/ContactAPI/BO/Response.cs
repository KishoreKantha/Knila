﻿using Microsoft.OpenApi.Any;

namespace ContactAPI.BO
{
    public class ContactResponse
    {
        public string Code { get; set; } = "200";
        public string Message { get; set; } = "";

    }
}
