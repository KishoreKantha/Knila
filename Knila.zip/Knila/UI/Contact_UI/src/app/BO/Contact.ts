export class Contact {
    id: number = 0
    firstName: string = ""
    lastName: string = ""
    email: string = ""
    password: string = ""
    phoneNumber: string = ""
    address: string = ""
    city: string = ""
    state: string = ""
    country: string = ""
    postalCode: string = ""
}
export class SignIn{
    Email: string = ""
    Password: string = ""
}